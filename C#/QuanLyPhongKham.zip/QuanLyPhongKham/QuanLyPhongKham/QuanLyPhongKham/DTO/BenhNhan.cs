﻿namespace QuanLyPhongKham.DTO
{
    public class BenhNhan
    {
        public int MaBN { get; set; }
        public string HoTenBN { get; set; }
        public int? NamSinhBN { get; set; }
        public string GioiTinhBN { get; set; }
        public string SDT_BN { get; set; }
        public string DiaChiBN { get; set; }
        public string TienSuBenh { get; set; }
    }
}