﻿using System;

namespace QuanLyPhongKham.DTO
{
    public class DichVu
    {
        public int MaDV { get; set; }
        public string TenDV { get; set; }
        public decimal GiaDV { get; set; }
    }
}